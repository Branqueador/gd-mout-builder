WARZONE: SAN ANDREAS
Modular Operations Urban Terrain

The three texture variations are split into three folders inside the 'stream' folder (standard, secondary, concrete)
The default ytyp included in the stream folder allows you to use the same props with different textures.

The concrete texture does not include all of the props, such as garages.
If you wish to have those as well, you just simply have to copy the props, rename, and add entry to ytyp.
IE: Renaming 'mout_garage_01' to 'mout_garage_07' and copying ytyp entry as well.

If you only want the standard props (One texture only) then use the ytyp file inside the 'Files' folder.
You can also change the standard texture by renaming the texture dictionary.
IE: Renaming 'dict_mout_t' to 'dict_mout_g' will make the standard props have the tan texture instead of green.

For any questions, comment on the release topic or visit our Discord: https://discordapp.com/invite/KedUfCW